module powerbi.visuals.plugins {
    export var lineChartRD902E64560EE4B62A6FFD29B1499B69E = {
        name: 'lineChartRD902E64560EE4B62A6FFD29B1499B69E',
        displayName: 'LineChartR',
        class: 'Visual',
        version: '1.0.0',
        apiVersion: '1.11.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.lineChartRD902E64560EE4B62A6FFD29B1499B69E.Visual(options),
        custom: true
    };
}
