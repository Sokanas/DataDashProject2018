module powerbi.visuals.plugins {
    export var barChart499A0A12A57F413881C384AA9A1840CB = {
        name: 'barChart499A0A12A57F413881C384AA9A1840CB',
        displayName: 'BarChart',
        class: 'Visual',
        version: '1.0.0',
        apiVersion: '1.11.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.barChart499A0A12A57F413881C384AA9A1840CB.Visual(options),
        custom: true
    };
}
