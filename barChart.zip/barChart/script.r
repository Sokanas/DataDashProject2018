source('./r_files/flatten_HTML.r')

############### Library Declarations ###############
libraryRequireInstall("ggplot2");
libraryRequireInstall("plotly");
libraryRequireInstall("htmlwidgets");
####################################################

################### Actual code ####################
dataFrame <- data.frame(Axis, Values[[1]]);

p <- plot_ly(Values,

  x = dataFrame[[1]],

  y = dataFrame[[2]],

  type = "bar"
)

### Attempt at accomodating multiple data series being put into Values

#iter = 1;
#ValueNo = NCOL(Values);
#while(iter < ValueNo){
	#dataFrame[[iter + 2]] = Values[[iter + 1]];
	#add_trace(p, y = Values[[(iter + 1)]]);
	#layout(p, yaxis = list(title = 'Count'), barmode = 'group');
	#iter = iter + 1;
#}


#d = plot_ly
####################################################

############# Create and save widget ###############
#p = ggplotly(p);
internalSaveWidget(p, 'out.html');
####################################################
