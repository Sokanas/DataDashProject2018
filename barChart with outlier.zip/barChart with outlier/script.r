source('./r_files/flatten_HTML.r')

############### Library Declarations ###############
libraryRequireInstall("ggplot2");
libraryRequireInstall("plotly");
libraryRequireInstall("htmlwidgets");

####################################################

################### Actual code ####################
dataFrame <- data.frame(Axis, Values[[1]]);  

#par(mfrow = c(1, 2))
#plot(dataFrame$Axis, dataFrame$Values[[1]], xlim = c(0, 100), ylim=c(0, 20), pch ="*", col = "red", cex = 2)
#abline(lm(data = dataFrame), col = "blue", lwd = 3, lty = 2)

#Setting default colouring to red and Threshold Colouring off
baseColour = "#FD625E"
thresholdActive = FALSE;
if(exists("ColourSettings_fill")){
	baseColour = as.character(ColourSettings_fill);
}
if(exists("ColourSettings_thresholdActive")){
	thresholdActive = as.logical(ColourSettings_thresholdActive);
}

#Threshold Colouring
if(thresholdActive){

	if(exists("ColourSettings_threshold1")){
		threshold1Value = ColourSettings_threshold1;
	}else{
		threshold1Value = 40;
	}
	if(exists("ColourSettings_colour1")){
		threshold1Colour = as.character(ColourSettings_colour1);
	}else{
		threshold1Colour = "#F2C80F";
	}
	if(exists("ColourSettings_threshold2")){
		threshold2Value = ColourSettings_threshold2;
	}else{
		threshold2Value = 70;
	}
	if(exists("ColourSettings_colour2")){
		threshold2Colour = as.character(ColourSettings_colour2);
	}else{
		threshold2Colour = "#01B8AA";
	}
	
	thresholds <- c(-Inf, threshold1Value, threshold2Value, Inf);
	colours <- c(baseColour,threshold1Colour,threshold2Colour)[findInterval(dataFrame[[2]], vec=thresholds)]


    min = min(dataFrame[[2]]);
	max = max(dataFrame[[2]]);
	for(cols in 1:ncol(Values)){

		if(min(Values[[cols]]) < min){
		min = min(Values[[cols]]);	
		}		
		if(max(Values[[cols]]) > max){
		max = max(Values[[cols]]);	
		}

	}


	for(cols in 1:ncol(Values)){

		if(exists("OutlierSettings_outlieractive")){
				outlieractive = as.logical(OutlierSettings_outlieractive);
				if(outlieractive){
			
					iqr1 = IQR(Values[[cols]]);
					min1 = min(Values[[cols]]) + iqr1;
					max1 = max(Values[[cols]]) - iqr1;
					for (vals in 1:nrow(Values)){
						if(Values[[cols]][[vals]] > max1){
							Values[[cols]] <- replace(Values[[cols]], vals, (max + 1));
						}	
						if(Values[[cols]][[vals]] < min1){
							Values[[cols]] <- replace(Values[[cols]], vals, (min - 1));
						}	
					}
				}
		}

	}		


	for(cols in 1:ncol(Values)){
	

		if(cols == 1){
			
			if(exists("OutlierSettings_outlieractive")){
				outlieractive = as.logical(OutlierSettings_outlieractive);
				if(outlieractive){
					
					iqr1 = IQR(dataFrame[[2]]);
					min1 = min(dataFrame[[2]]) + iqr1;
					max1 = max(dataFrame[[2]]) - iqr1;
					for (vals in 1:nrow(Values)){
						if(dataFrame[[2]][[vals]] > max1){
							dataFrame[[2]] <- replace(dataFrame[[2]], vals, (max + 1));
						}	
						if(dataFrame[[2]][[vals]] < min1){
							dataFrame[[2]] <- replace(dataFrame[[2]], vals, (min -1));
						}	
					}

				}
			}
        }
    }
	
	p <- plot_ly(Values,
		x = dataFrame[[1]],
		y = dataFrame[[2]],
		type = "bar",
		marker = list(color = colours),
        transforms = list(
					list(
						type = 'filter',
						target = 'y',
						operation = '<=',
						value = max 
					),
					list(
						type = 'filter',
						target = 'y',
						operation = '>=',
						value = min 
					)
				)
	) %>%

	rangeslider(dataFrame$x[10], dataFrame$x[100000])




}else{ #No Threshold Colouring

    

    
   	min = min(dataFrame[[2]]);
	max = max(dataFrame[[2]]);
	for(cols in 1:ncol(Values)){

		if(min(Values[[cols]]) < min){
		min = min(Values[[cols]]);	
		}		
		if(max(Values[[cols]]) > max){
		max = max(Values[[cols]]);	
		}

	}


	for(cols in 1:ncol(Values)){

		if(exists("OutlierSettings_outlieractive")){
				outlieractive = as.logical(OutlierSettings_outlieractive);
				if(outlieractive){
			
					iqr1 = IQR(Values[[cols]]);
					min1 = min(Values[[cols]]) + iqr1;
					max1 = max(Values[[cols]]) - iqr1;
					for (vals in 1:nrow(Values)){
						if(Values[[cols]][[vals]] > max1){
							Values[[cols]] <- replace(Values[[cols]], vals, (max + 1));
						}	
						if(Values[[cols]][[vals]] < min1){
							Values[[cols]] <- replace(Values[[cols]], vals, (min - 1));
						}	
					}
				}
		}

	}		


	for(cols in 1:ncol(Values)){
	

		if(cols == 1){
			
			if(exists("OutlierSettings_outlieractive")){
				outlieractive = as.logical(OutlierSettings_outlieractive);
				if(outlieractive){
					
					iqr1 = IQR(dataFrame[[2]]);
					min1 = min(dataFrame[[2]]) + iqr1;
					max1 = max(dataFrame[[2]]) - iqr1;
					for (vals in 1:nrow(Values)){
						if(dataFrame[[2]][[vals]] > max1){
							dataFrame[[2]] <- replace(dataFrame[[2]], vals, (max + 1));
						}	
						if(dataFrame[[2]][[vals]] < min1){
							dataFrame[[2]] <- replace(dataFrame[[2]], vals, (min -1));
						}	
					}

				}
		    }
        } 

    }


	p <- plot_ly(Values,
		x = dataFrame[[1]],
		y = dataFrame[[2]],
		type = "bar",
		marker = list(color = baseColour),
        transforms = list(
					list(
						type = 'filter',
						target = 'y',
						operation = '<=',
						value = max 
					),
					list(
						type = 'filter',
						target = 'y',
						operation = '>=',
						value = min 
					)
				)
	) %>%

	rangeslider(dataFrame$x[10], dataFrame$x[100000])

    

    #quantiles <- quantile(dataFrame$y, probs = c(0, 1))
    #range <- 1.5 * IQR(dataFrame$y)
    #p2 <- subset(dataFrame, dataFrame$y > (quantiles[1] - range) & dataFrame$y < (quantiles[2] + range))

    #p <- add_trace(p, type="scatter", )
}







####################################################

############# Create and save widget ###############
#p = ggplotly(p);
internalSaveWidget(p, 'out.html');
####################################################
